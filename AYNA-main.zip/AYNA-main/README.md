# AYNA
<a href="https://royishan.github.io/ayna.github.io/index.html"> Click Here for Website</a>
<br>
AYNA (All You Need for Agronomy) is a website particularly for the Indian Farmers to provide all information in one portal.
